﻿using System;
using System.Data;

class Program
{
    static void Main()
    {
        //  Create DataSet
        DataSet CompanyDataSet = new DataSet("CompanyDataSet");

        // Create Department DataTable
        DataTable Department = new DataTable("Department");

        Department.Columns.Add("DeptId", typeof(int));
        Department.Columns.Add("DeptName", typeof(string));

        // Set Primary Key
        Department.PrimaryKey = new DataColumn[]
        {
            Department.Columns["DeptId"]!
        };

        // Create Employee DataTable
        DataTable Employee = new DataTable("Employee");

        Employee.Columns.Add("EmpId", typeof(int));
        Employee.Columns.Add("EmpName", typeof(string));
        Employee.Columns.Add("Salary", typeof(decimal));
        Employee.Columns.Add("DeptId", typeof(int));

        // Set Primary Key
        Employee.PrimaryKey = new DataColumn[]
        {
            Employee.Columns["EmpId"]!
        };

        // Add tables to DataSet
        CompanyDataSet.Tables.Add(Department);
        CompanyDataSet.Tables.Add(Employee);


        // INSERT DEPARTMENT RECORDS
        DataRow deptRow;
        deptRow = Department.NewRow();
        deptRow["DeptId"] = 1;
        deptRow["DeptName"] = "IT";
        Department.Rows.Add(deptRow);

        deptRow = Department.NewRow();
        deptRow["DeptId"] = 2;
        deptRow["DeptName"] = "HR";
        Department.Rows.Add(deptRow);

        deptRow = Department.NewRow();
        deptRow["DeptId"] = 3;
        deptRow["DeptName"] = "Finance";
        Department.Rows.Add(deptRow);


        // INSERT EMPLOYEE RECORDS
        DataRow empRow;
        empRow = Employee.NewRow();
        empRow["EmpId"] = 101;
        empRow["EmpName"] = "Maulik";
        empRow["Salary"] = 30000;
        empRow["DeptId"] = 1;
        Employee.Rows.Add(empRow);

        empRow = Employee.NewRow();
        empRow["EmpId"] = 102;
        empRow["EmpName"] = "Amit";
        empRow["Salary"] = 35000;
        empRow["DeptId"] = 1;
        Employee.Rows.Add(empRow);

        empRow = Employee.NewRow();
        empRow["EmpId"] = 103;
        empRow["EmpName"] = "Ayush";
        empRow["Salary"] = 40000;
        empRow["DeptId"] = 2;
        Employee.Rows.Add(empRow);

        empRow = Employee.NewRow();
        empRow["EmpId"] = 104;
        empRow["EmpName"] = "Prakash";
        empRow["Salary"] = 45000;
        empRow["DeptId"] = 2;
        Employee.Rows.Add(empRow);

        empRow = Employee.NewRow();
        empRow["EmpId"] = 105;
        empRow["EmpName"] = "Raj";
        empRow["Salary"] = 50000;
        empRow["DeptId"] = 3;
        Employee.Rows.Add(empRow);


        // DISPLAY DEPARTMENTS

        Console.WriteLine("----- DEPARTMENTS -----");

        foreach (DataRow row in Department.Rows)
        {
            Console.WriteLine(
                "DeptId: " + row["DeptId"] +
                ", DeptName: " + row["DeptName"]
            );
        }


        // DISPLAY EMPLOYEES

        Console.WriteLine("\n----- EMPLOYEES -----");

        foreach (DataRow row in Employee.Rows)
        {
            Console.WriteLine(
                "EmpId: " + row["EmpId"] +
                ", Name: " + row["EmpName"] +
                ", Salary: " + row["Salary"] +
                ", DeptId: " + row["DeptId"]
            );
        }


        // UPDATE EMPLOYEE SALARY

        Console.WriteLine("\n----- UPDATE SALARY -----");

        DataRow foundRow = Employee.Rows.Find(101)!;

        if (foundRow != null)
        {
            foundRow["Salary"] = 40000;

            Console.WriteLine(
                "Salary updated for " + foundRow["EmpName"]
            );
        }


        // DELETE EMPLOYEE

        Console.WriteLine("\n----- DELETE EMPLOYEE -----");

        DataRow deleteRow = Employee.Rows.Find(105)!;

        if (deleteRow != null)
        {
            Console.WriteLine(
                "Deleted Employee: " + deleteRow["EmpName"]
            );

            Employee.Rows.Remove(deleteRow);
        }


        // CREATE DATA RELATION

        DataRelation relation = new DataRelation(
            "DepartmentEmployee",
            Department.Columns["DeptId"]!,
            Employee.Columns["DeptId"]!
        );

        CompanyDataSet.Relations.Add(relation);


        // DISPLAY EMPLOYEES DEPARTMENT-WISE

        Console.WriteLine("\n----- DEPARTMENT-WISE EMPLOYEES -----");

        foreach (DataRow dept in Department.Rows)
        {
            Console.WriteLine(
                "\nDepartment: " + dept["DeptName"]
            );

            DataRow[] employees = dept.GetChildRows(relation);

            foreach (DataRow employee in employees)
            {
                Console.WriteLine(
                    "  EmpId: " + employee["EmpId"] +
                    ", Name: " + employee["EmpName"] +
                    ", Salary: " + employee["Salary"]
                );
            }
        }
    }
}