using System;
using System.Collections.Generic;
using System.Linq;

namespace CSharp
{
    class LinqJoin
    {
        public static void Run()
        {
            IList<Student> studentList = new List<Student>()
            {
                new Student() { StudentID = 1, StudentName = "Ayush", Age = 18, StandardID = 1 },
                new Student() { StudentID = 2, StudentName = "prakash", Age = 21, StandardID = 1 },
                new Student() { StudentID = 3, StudentName = "dhruvil", Age = 18, StandardID = 2 },
                new Student() { StudentID = 4, StudentName = "priyanshu", Age = 20, StandardID = 2 },
                new Student() { StudentID = 5, StudentName = "maulik", Age = 21 }
            };

            IList<Standard> standardList = new List<Standard>()
            {
                new Standard(){ StandardID = 1, StandardName = "Standard 1" },
                new Standard(){ StandardID = 2, StandardName = "Standard 2" },
                new Standard(){ StandardID = 3, StandardName = "Standard 3" }
            };

            var innerJoinResult =
                from student in studentList
                join standard in standardList
                    on student.StandardID equals standard.StandardID into oj
                from student2 in oj.DefaultIfEmpty()
                select new
                {
                    StudentName = student.StudentName,
                    StandardName = student2?.StandardName ?? "Not Assigned"
                };

            foreach (var obj in innerJoinResult)
                Console.WriteLine("{0} - {1}", obj.StudentName, obj.StandardName);
        }
    }

    public class Student
    {
        public int StudentID { get; set; }
        public string StudentName { get; set; }
        public int Age { get; set; }
        public int StandardID { get; set; }
    }

    public class Standard
    {
        public int StandardID { get; set; }
        public string StandardName { get; set; }
    }
}
