using System;
using System.Collections.Generic;
using System.Linq;

namespace CSharp
{
    public class LinqObj
    {
        public static bool IsTeenAger(Student stud)
        {
            return stud.Age > 12 && stud.Age < 20;
        }

        public class Student
        {
            public int StudentID { get; set; }
            public string StudentName { get; set; }
            public int Age { get; set; }
        }

        public static void Run()
        {
            IList<Student> studentList = new List<Student>()
            {
                new Student() { StudentID = 1, StudentName = "Ayush", Age = 22 },
                new Student() { StudentID = 2, StudentName = "prakash", Age = 20 },
                new Student() { StudentID = 3, StudentName = "jenil", Age = 18 },
                new Student() { StudentID = 4, StudentName = "Dhruvil", Age = 13 },
                new Student() { StudentID = 5, StudentName = "Maulik", Age = 14 },
                new Student() { StudentID = 6, StudentName = "Deep", Age = 19 },
                new Student() { StudentID = 7, StudentName = "krish", Age = 12 },
                new Student() { StudentID = 8, StudentName = "Shivam", Age = 17 }
            };

            var groupedResult = from s in studentList
                                group s by s.Age;

            foreach (var ageGroup in groupedResult)
            {
                Console.WriteLine("Age Group: {0}", ageGroup.Key);
                Console.WriteLine(ageGroup.Max(s => s.StudentID));
                Console.WriteLine(ageGroup.Count());

                foreach (Student std in ageGroup)
                    Console.WriteLine("ID : " + std.StudentID + " Name : " + std.StudentName + " Age :" + std.Age);
            }

            // Other LINQ examples from the image:
            // var filteredResult = studentList.Where(s => s.Age > 12 && s.Age < 20);
            // var filteredResult = studentList.OrderByDescending(s => s.Age).ThenBy(s => s.StudentName);
            // Console.WriteLine(studentList.Sum(s => s.Age));
            // Console.WriteLine(studentList.Max(s => s.Age));
            // Console.WriteLine(studentList.Min(s => s.Age));
            // Console.WriteLine(studentList.Average(s => s.Age));
        }
    }
}
