using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using Npgsql;

namespace CSharp
{
    class LinqTab
    {
        class Book
        {
            public int BookId { get; set; }
            public string BookName { get; set; }
            public string Author { get; set; }
        }

        private const string ConnectionString =
            "Server=localhost;Port=5432;Database=postgres;User Id=postgres;Password=033911;";

        public static void EmpMain()
        {
            using NpgsqlConnection con = new NpgsqlConnection(ConnectionString);
            NpgsqlCommand com = new NpgsqlCommand("select * from t_employee", con);
            NpgsqlDataAdapter da = new NpgsqlDataAdapter(com);
            DataSet ds = new DataSet();
            da.Fill(ds);

            var eList = (from DataRow dr in ds.Tables[0].Rows
                         where dr["EmpName"].ToString().EndsWith("an")
                         select new
                         {
                             EmpNo = Convert.ToInt32(dr["EmpId"]),
                             EmpName = dr["EmpName"].ToString(),
                             Salary = dr["Salary"].ToString(),
                             DeptNo = dr["DeptNo"].ToString()
                         }).ToList();

            foreach (var emp in eList)
                Console.WriteLine($"ID : {emp.EmpNo} Name : {emp.EmpName} Salary : {emp.Salary} DeptNo: {emp.DeptNo}");
        }

        public static void Run()
        {
            Console.WriteLine("------------------------------------------------------------------");

            using NpgsqlConnection con = new NpgsqlConnection(ConnectionString);
            NpgsqlCommand com = new NpgsqlCommand("select * from t_book", con);
            con.Open();
            NpgsqlDataReader datar = com.ExecuteReader();

            DataTable dt = new DataTable();
            if (datar.HasRows)
                dt.Load(datar);

            con.Close();

            List<Book> bookList = (from DataRow dr in dt.Rows
                                   select new Book()
                                   {
                                       BookId = Convert.ToInt32(dr["bookId"]),
                                       BookName = dr["BookName"].ToString(),
                                       Author = dr["Author"].ToString()
                                   }).ToList();

            foreach (Book book in bookList)
                Console.WriteLine($"ID : {book.BookId} Name : {book.BookName} Author : {book.Author}");
        }
    }
}
