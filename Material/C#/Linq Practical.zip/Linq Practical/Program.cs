using System;

namespace CSharp
{
    class Program
    {
        static void Main(string[] args)
        {
            while (true)
            {
                Console.Clear();
                Console.WriteLine("==============================");
                Console.WriteLine("       LINQ / EVENT MENU");
                Console.WriteLine("==============================");
                Console.WriteLine("1. Event");
                Console.WriteLine("2. LINQ Basic");
                Console.WriteLine("3. LINQ Object");
                Console.WriteLine("4. LINQ Join");
                Console.WriteLine("5. LINQ Table (PostgreSQL)");
                Console.WriteLine("6. Regular Expression");
                Console.WriteLine("0. Exit");
                Console.WriteLine("==============================");
                Console.Write("Enter choice: ");

                string choice = Console.ReadLine();
                Console.Clear();

                try
                {
                    switch (choice)
                    {
                        case "1": EventTest.Run(); break;
                        case "2": LinqTest.Run(); break;
                        case "3": LinqObj.Run(); break;
                        case "4": LinqJoin.Run(); break;
                        case "5": LinqTab.Run(); break;
                        case "6": RegExTest.Run(); break;
                        case "0": return;
                        default: Console.WriteLine("Invalid choice!"); break;
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine("Error: " + ex.Message);
                }

                Console.WriteLine("\nPress ENTER to return to menu...");
                Console.ReadLine();
            }
        }
    }
}
