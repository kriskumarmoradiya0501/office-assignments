using System;
using System.Linq;

namespace CSharp
{
    class LinqTest
    {
        public static void Run()
        {
            string[] names = { "Ayush", "prakash", "dhruvil", "priyanshu" };

            var query = from name in names
                        where name.Contains("e")
                        select name;

            foreach (var name in query)
                Console.WriteLine(name + " ");
        }
    }
}
