using System;

namespace CSharp
{
    public delegate void MyDel(string str);

    class EventTest
    {
        public event MyDel MyEvent;

        public EventTest()
        {
            this.MyEvent += new MyDel(this.WelcomeUser);
        }

        public void WelcomeUser(string username)
        {
            Console.WriteLine($"Welcome {username}");
        }

        public void HiUser(string username)
        {
            Console.WriteLine($"Hi {username}");
        }

        public void SetEvent()
        {
            this.MyEvent = new MyDel(this.HiUser);
        }

        public static void Run()
        {
            EventTest obj1 = new EventTest();
            obj1.MyEvent?.Invoke("Ayush Patel");

            obj1.SetEvent();
            obj1.MyEvent?.Invoke("Ayush Patel");
        }
    }
}
