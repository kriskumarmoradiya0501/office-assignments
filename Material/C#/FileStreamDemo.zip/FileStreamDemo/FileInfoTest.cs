using System;
using System.IO;

class FileInfoTest
{
    static string path = "test1.txt";
    static string copyPath = "test_copy.txt";
    static string movePath = "test_folder/test.txt";
    static string renamePath = "renamed_test.txt";


    // Check whether file exists
    public static void CreateFileInfo()
    {
        FileInfo file = new FileInfo(path);

        if (!file.Exists)
        {
            file.Create().Close();
            Console.WriteLine("File created successfully.");
        }
        else
        {
            Console.WriteLine("File already exists.");
        }
    }


    // Display file information
    public static void FileInfoObject()
    {
        FileInfo file = new FileInfo(path);

        Console.WriteLine("File Name: " + file.Name);
        Console.WriteLine("File Extension: " + file.Extension);
        Console.WriteLine("File Size: " + file.Length + " bytes");
        Console.WriteLine("Full File Path: " + file.FullName);
        Console.WriteLine("Creation Date: " + file.CreationTime);
        Console.WriteLine("Last Modified Date: " + file.LastWriteTime);
    }

    // Copy a file
    public static void CopyFile()
    {
        FileInfo file = new FileInfo(path);

        file.CopyTo(copyPath, true);

        Console.WriteLine("File copied successfully.");
    }


    // Move a file
    public static void MoveFile()
    {
        FileInfo file = new FileInfo(copyPath);

        Directory.CreateDirectory("test_folder");

        file.MoveTo(movePath, true);

        Console.WriteLine("File moved successfully.");
    }


    // Rename a file
    public static void RenameFile()
    {
        FileInfo file = new FileInfo(path);

        file.MoveTo(renamePath, true);

        Console.WriteLine("File renamed successfully.");
    }


    // Delete a file
    public static void DeleteFile()
    {
        FileInfo file = new FileInfo(renamePath);

        if (file.Exists)
        {
            file.Delete();

            Console.WriteLine("File deleted successfully.");
        }
        else
        {
            Console.WriteLine("File does not exist.");
        }
    }
}