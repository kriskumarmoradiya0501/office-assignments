using System;
using System.IO;
using System.Text;

class DirectoryFileTest
{
    static string folderPath = "MyFolder";
    static string subFolderPath = "MyFolder/SubFolder";
    static string movedFolderPath = "MovedFolder";
    static string filePath = "MyFolder/test.txt";
    static string copyFilePath = "MyFolder/test_copy.txt";
    static string movedFilePath = "MyFolder/MovedFile.txt";
    static string renamedFilePath = "MyFolder/RenamedFile.txt";


    // Create a folder using Directory
    public static void CreateFolder()
    {
        if (!Directory.Exists(folderPath))
        {
            Directory.CreateDirectory(folderPath);
            Console.WriteLine("Folder created successfully.");
        }
        else
        {
            Console.WriteLine("Folder already exists.");
        }
    }

    // Create subfolder
    public static void CreateSubFolder()
    {
        if (!Directory.Exists(subFolderPath))
        {
            Directory.CreateDirectory(subFolderPath);
            Console.WriteLine("Subfolder created successfully.");
        }
        else
        {
            Console.WriteLine("Subfolder already exists.");
        }
    }

    // Create file inside folder
    public static void CreateFile()
    {
        if (!File.Exists(filePath))
        {
            FileStream fs = new FileStream(filePath, FileMode.Create, FileAccess.Write);
            fs.Close();
            Console.WriteLine("File created successfully.");
        }
        else
        {
            Console.WriteLine("File already exists.");
        }
    }

    // Write data into file
    public static void WriteData()
    {
        FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Write);
        StreamWriter sw = new StreamWriter(fs);

        sw.WriteLine("Hello, this is my file.");
        sw.WriteLine("This file is created using C#.");
        sw.WriteLine("Directory and File handling.");

        sw.Close();
        fs.Close();

        Console.WriteLine("Data written successfully.");
    }

    // Read data from file
    public static void ReadData()
    {
        FileStream fs = new FileStream(filePath, FileMode.Open, FileAccess.Read);
        StreamReader sr = new StreamReader(fs);
        Console.WriteLine("\nFile Data:");
        string? data;
        while ((data = sr.ReadLine()) != null)
        {
            Console.WriteLine(data);
        }
        sr.Close();
        fs.Close();
    }

    // Copy file
    public static void CopyFile()
    {
        if (File.Exists(filePath))
        {
            File.Copy(filePath, copyFilePath,true);
            Console.WriteLine("File copied successfully.");
        }
        else
        {
            Console.WriteLine("Original file does not exist.");
        }
    }

    // Move file
    public static void MoveFile()
    {
        if (File.Exists(copyFilePath))
        {
            File.Move(copyFilePath, movedFilePath,true);
            Console.WriteLine("File moved successfully.");
        }
        else
        {
            Console.WriteLine("File to move does not exist.");
        }
    }

    // Rename file
    public static void RenameFile()
    {
        if (File.Exists(movedFilePath))
        {
            File.Move(movedFilePath, renamedFilePath,true);
            Console.WriteLine("File renamed successfully.");
        }
        else
        {
            Console.WriteLine("File to rename does not exist.");
        }
    }

    // Display creation/modification dates
    public static void DisplayFileDates()
    {
        if (File.Exists(renamedFilePath))
        {
            DateTime creationDate = File.GetCreationTime(renamedFilePath);
            DateTime modificationDate = File.GetLastWriteTime(renamedFilePath);
            Console.WriteLine("Creation Date: " + creationDate);
            Console.WriteLine("Modification Date: " + modificationDate);
        }
        else
        {
            Console.WriteLine("File does not exist.");
        }
    }


    // List files from folder
    public static void ListFiles()
    {
        if (Directory.Exists(folderPath))
        {
            string[] files = Directory.GetFiles(folderPath);
            Console.WriteLine("\nFiles in folder:");
            foreach (string file in files)
            {
                Console.WriteLine(file);
            }
        }
        else
        {
            Console.WriteLine("Folder does not exist.");
        }
    }

    // Search files by extension
    public static void SearchByExtension()
    {
        if (Directory.Exists(folderPath))
        {
            string[] txtFiles = Directory.GetFiles(folderPath, "*.txt");
            Console.WriteLine("\nTXT files:");
            foreach (string file in txtFiles)
            {
                Console.WriteLine(file);
            }
        }
        else
        {
            Console.WriteLine("Folder does not exist.");
        }
    }

    //  Delete file
    public static void DeleteFile()
    {
        if (File.Exists(renamedFilePath))
        {
            File.Delete(renamedFilePath);
            Console.WriteLine("File deleted successfully.");
        }
        else
        {
            Console.WriteLine("File does not exist.");
        }
    }

    // Move folder
    public static void MoveFolder()
    {
        if (Directory.Exists(folderPath))
        {
            if (!Directory.Exists(movedFolderPath))
            {
                Directory.Move(folderPath, movedFolderPath);
                Console.WriteLine("Folder moved successfully.");
            }
            else
            {
                Console.WriteLine("Destination folder already exists.");
            }
        }
        else
        {
            Console.WriteLine("Folder does not exist.");
        }
    }

    // Delete folder
    public static void DeleteFolder()
    {
        if (Directory.Exists(movedFolderPath))
        {
            Directory.Delete(movedFolderPath,true);
            Console.WriteLine("Folder deleted successfully.");
        }
        else
        {
            Console.WriteLine("Folder does not exist.");
        }
    }
}