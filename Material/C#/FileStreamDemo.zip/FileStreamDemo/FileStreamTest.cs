using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.IO;
using System.Text;

class FileStreamTest
{

    static string path = "test.txt";

    // Create a file using FileStream
    public static void CreateFile()
    {
        FileStream fs = new FileStream(path, FileMode.Create, FileAccess.Write);
    }

    // Write to a file using FileStream
    public static void WriteToFile()
    {
        FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Write);
        StreamWriter sw = new StreamWriter(fs);
        Console.WriteLine("Enter text to write:");
        string str = Console.ReadLine();
        sw.WriteLine(str);
        sw.Flush();
        sw.Close();
        fs.Close();
        Console.WriteLine("File written successfully.");
    }

    // Read from a file using FileStream
    public static void ReadFromFile()
    {
        FileStream fs = new FileStream(path, FileMode.Open, FileAccess.Read);
        StreamReader sr = new StreamReader(fs); 
        Console.WriteLine("Reading from file:");
        sr.BaseStream.Seek(2, SeekOrigin.Begin);
        string line;
        while ((line = sr.ReadLine()) != null)
        {
            Console.WriteLine(line);
        }
        Console.WriteLine("Length: " + fs.Length);
        Console.WriteLine("Position: " + fs.Position);
        sr.Close();
        fs.Close();
    }

    // Append to a file using FileStream
    public static void AppendToFile()
    {
        FileStream fs = new FileStream(path, FileMode.Append, FileAccess.Write);
        StreamWriter sw = new StreamWriter(fs);
        Console.WriteLine("Enter text to append:");
        string str = Console.ReadLine();
        sw.WriteLine(str);
        sw.Flush();
        sw.Close();
        fs.Close();
        Console.WriteLine("Text appended successfully.");
    }
}