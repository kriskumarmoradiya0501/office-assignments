﻿class Program
{
    static void Main(string[] args)
    {
        // FileStreamTest.CreateFile();
        // FileStreamTest.WriteToFile();
        // FileStreamTest.ReadFromFile();
        // FileStreamTest.AppendToFile();

        // FileInfoTest.FileInfoObject();
        // FileInfoTest.CreateFileInfo();
        // FileInfoTest.CopyFile();
        // FileInfoTest.MoveFile();
        // FileInfoTest.RenameFile();
        // FileInfoTest.DeleteFile();

        // DirectoryFileTest.CreateFolder();
        // DirectoryFileTest.CreateFile();
        // DirectoryFileTest.WriteData();
        // DirectoryFileTest.ReadData();
        // DirectoryFileTest.CopyFile();
        // DirectoryFileTest.MoveFile();
        // DirectoryFileTest.RenameFile();
        // DirectoryFileTest.DeleteFile();
        // DirectoryFileTest.MoveFolder();
        // DirectoryFileTest.DeleteFolder();

    }
}